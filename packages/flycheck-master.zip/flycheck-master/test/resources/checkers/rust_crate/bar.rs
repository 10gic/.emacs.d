pub static BAR: int = 42;
