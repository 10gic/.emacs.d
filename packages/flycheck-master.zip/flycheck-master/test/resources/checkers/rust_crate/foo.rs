use super::bar;
pub fn foo() {
    let x = "10";
    println!("hey {}", bar::BAR);
}
