// Scala style warning

object Warning {

  class WarningClass {}
}
