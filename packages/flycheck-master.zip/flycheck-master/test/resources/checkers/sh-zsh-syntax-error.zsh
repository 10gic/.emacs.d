#!/bin/zsh

if true then
   echo "Hello World"
fi
