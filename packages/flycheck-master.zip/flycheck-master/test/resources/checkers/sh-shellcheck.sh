#!/bin/sh
rm "~/my file.txt"
touch $@
export LS=`which ls`
