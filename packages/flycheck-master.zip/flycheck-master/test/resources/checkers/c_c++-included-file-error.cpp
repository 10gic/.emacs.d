class test {};

#include "c_c++-warning.c"
