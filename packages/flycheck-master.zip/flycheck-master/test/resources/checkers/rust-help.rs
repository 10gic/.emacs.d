// A help message from rustc

fn test() -> i64 {
    32_i64;
}
