// Scala style error

object Error {

  def main(args:Array[String]): Unit =
    println("hello, world")
}
