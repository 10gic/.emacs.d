// A syntax error in a test

#[test]
fn some_test() {
    bla;
}
