void foo() { throw 5; }
