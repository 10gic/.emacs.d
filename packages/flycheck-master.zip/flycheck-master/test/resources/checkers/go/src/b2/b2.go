package b2

func Call() string {
	return "b2"
}
