import qualified Data.ByteString as BS

main :: IO ()
main = BS.putStr "Hello World\n"
