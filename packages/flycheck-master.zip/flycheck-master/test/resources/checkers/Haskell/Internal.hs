module Haskell.Internal (bar)
where

bar :: String
bar = "bar"
