============================
 GNU General Public License
============================

.. include:: ../COPYING
   :literal:
