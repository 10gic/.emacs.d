===================
 Flycheck releases
===================

This document contains the release announcements for Flycheck, and the complete
changelog.

Release announcements
=====================

.. toctree::
   :maxdepth: 1

   flycheck-0.22
   flycheck-0.21
   flycheck-0.20
   flycheck-0.19
   flycheck-0.18
   flycheck-0.17
   flycheck-0.16
   flycheck-0.15

.. _changelog:

Changelog
=========

.. include:: ../../../CHANGES.rst
